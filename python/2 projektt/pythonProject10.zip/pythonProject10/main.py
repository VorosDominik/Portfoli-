import feladatok
feladatok.osszegzes(feladatok.gG_lista(3))